<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Registros</title>
    <link rel="stylesheet" href="https://cdn.simplecss.org/simple.min.css">
</head>
<body>
    <h1>Lista de Registros</h1>
    <a href="index.php?action=add">Añadir nuevo registro</a>
    <?php echo $bodyOutput; ?>
</body>
</html>