<?php

$usersFile;
$postsFile;

$arrayResultados = [];
$arrayCriterios = [];
?>